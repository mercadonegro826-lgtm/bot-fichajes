@echo off
title Bot de Fichajes - Discord
color 0A
echo Iniciando el Bot de Fichajes...
echo ----------------------------------------
if not exist node_modules (
    echo Instalando dependencias por primera vez...
    call npm install
)
echo Abriendo bot...
node index.js
pause
